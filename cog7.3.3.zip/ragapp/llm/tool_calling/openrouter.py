"""Direct OpenRouter SDK adapter."""
from __future__ import annotations

import json
import os
from typing import Any

from openrouter import OpenRouter

from ragapp.config import get_api_key, load_project_config

DEFAULT_OPENROUTER_MODEL = "openrouter/free"


# ---------------------------------------------------------------- settings

def _settings(store):
    cfg = load_project_config(store)
    provider = cfg.setdefault("provider", {})
    configured = os.getenv("OPENROUTER_MODEL") or provider.get("model")

    # Never send another provider's model name (e.g. gemini-*) to OpenRouter.
    if (
        not configured
        or configured.startswith("gemini")
        or ("/" not in configured and configured != DEFAULT_OPENROUTER_MODEL)
    ):
        return cfg, DEFAULT_OPENROUTER_MODEL
    return cfg, configured


def _client(store):
    key = get_api_key(store, "openrouter")
    if not key:
        raise RuntimeError(
            "No OpenRouter API key configured. "
            "Add it in Project Settings or set OPENROUTER_API_KEY."
        )

    provider = load_project_config(store).get("provider", {})
    kwargs = {"api_key": key}
    if provider.get("site_url"):
        kwargs["http_referer"] = provider["site_url"]
    if provider.get("site_name"):
        kwargs["x_open_router_title"] = provider["site_name"]
    return OpenRouter(**kwargs)


# ------------------------------------------------------- tool-call helpers

def _get(obj, key, default=None):
    """Read a field from either a dict or an SDK object."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _args_json(args):
    """Tool-call arguments as a JSON string."""
    if args is None:
        return "{}"
    if isinstance(args, str):
        return args
    if isinstance(args, (dict, list)):
        return json.dumps(args, ensure_ascii=False)
    return str(args)


def _tool_call(call_id, name, arguments):
    """The single place that builds the strict OpenAI/OpenRouter tool-call shape."""
    return {
        "id": str(call_id or f"call_{name}"),
        "type": "function",
        "function": {"name": str(name), "arguments": _args_json(arguments)},
    }


def _canonical_tool_call(call):
    """Normalize a tool call (SDK object or dict) to the strict shape."""
    if call is None:
        return None
    fn = _get(call, "function") or {}
    name = _get(fn, "name") or _get(call, "name")
    if not name:
        return None
    args = _get(fn, "arguments", _get(call, "arguments", "{}"))
    return _tool_call(_get(call, "id"), name, args)


# ------------------------------------------------- request-side conversion

def to_provider_contents(contents, store=None):
    """Convert internal messages into OpenRouter messages."""
    out = []
    for item in contents:
        if not isinstance(item, dict):
            continue

        role = item.get("role", "user")
        content = item.get("content", "")

        if role == "assistant" and item.get("tool_calls"):
            calls = [
                c
                for c in map(_canonical_tool_call, item["tool_calls"])
                if c is not None
            ]
            msg = {"role": "assistant", "content": item.get("content")}
            if calls:
                msg.update(tool_calls=calls, content=None)
            out.append(msg)

        elif role == "tool":
            call_id = item.get("tool_call_id") or item.get("id")
            if call_id:
                out.append(
                    {"role": "tool", "tool_call_id": str(call_id), "content": content}
                )
            else:
                # Orphaned tool result: can't be sent as a tool message.
                out.append({"role": "user", "content": content})

        elif role == "system":
            out.append({"role": "system", "content": content})

        else:
            out.append({"role": "user", "content": content})
    return out


def to_openrouter_tools(declarations):
    """Convert internal tool declarations to OpenRouter tool format."""
    return [
        {
            "type": "function",
            "function": {
                "name": d["name"],
                "description": d.get("description", ""),
                "parameters": d.get(
                    "parameters", {"type": "object", "properties": {}}
                ),
            },
        }
        for d in declarations
    ]


# ------------------------------------------------ response-side extraction

def _extract_message(response):
    if not getattr(response, "choices", None):
        raise RuntimeError("OpenRouter returned no choices.")
    return response.choices[0].message


def _extract_tool_calls(message):
    calls = []
    for call in getattr(message, "tool_calls", None) or []:
        fn = getattr(call, "function", None)
        name = getattr(fn, "name", None)
        if not name:
            continue

        raw_args = getattr(fn, "arguments", "{}") or "{}"
        try:
            args = json.loads(raw_args)
        except (TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"OpenRouter returned invalid JSON arguments for tool '{name}': {exc}"
            ) from exc

        calls.append(
            {
                "id": getattr(call, "id", None),
                "name": name,
                "args": args if isinstance(args, dict) else {},
            }
        )
    return calls


def _build_assistant_message(message, tool_calls):
    """Assistant message to append to history for the next step."""
    if not tool_calls:
        return {"role": "assistant", "content": getattr(message, "content", None)}
    return {
        "role": "assistant",
        "content": None,
        "tool_calls": [
            _tool_call(c.get("id"), c["name"], c["args"]) for c in tool_calls
        ],
    }


def _extract_usage(response):
    usage = getattr(response, "usage", None)
    if usage is None:
        return None
    return {
        k: getattr(usage, k, None)
        for k in ("prompt_tokens", "completion_tokens", "total_tokens")
    }


# ------------------------------------------------------------ public API

def generate_step(
    contents,
    function_declarations,
    system_instruction=None,
    store=None,
):
    """Generate one agent step through the native OpenRouter SDK."""
    if store is None:
        raise RuntimeError(
            "OpenRouter requires a project store so its API key "
            "and model can be resolved."
        )

    _, model = _settings(store)
    client = _client(store)

    messages = to_provider_contents(contents, store)
    if system_instruction:
        messages.insert(0, {"role": "system", "content": system_instruction})

    kwargs: dict[str, Any] = {"model": model, "messages": messages}
    if function_declarations:
        kwargs["tools"] = to_openrouter_tools(function_declarations)
        kwargs["tool_choice"] = "auto"

    try:
        response = client.chat.send(**kwargs)
    except Exception as exc:
        raise RuntimeError(
            f"OpenRouter request failed for model '{model}': {exc}"
        ) from exc

    message = _extract_message(response)
    tool_calls = _extract_tool_calls(message)

    return {
        "function_calls": tool_calls,
        "text": None if tool_calls else getattr(message, "content", None),
        "model_content": _build_assistant_message(message, tool_calls),
        "usage": _extract_usage(response),
        "model": model,
    }


def build_function_response_content(name, result, call_id=None):
    """Build a tool result message for the next agent step."""
    return {
        "role": "tool",
        "tool_call_id": call_id or name,
        "content": json.dumps(result, ensure_ascii=False, default=str),
    }


def generate_json(store, prompt, model=None):
    """Generate JSON for cognition compilation through OpenRouter."""
    client = _client(store)
    model = model or _settings(store)[1]
    request = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 8000,
    }

    try:
        response = client.chat.send(
            **request, response_format={"type": "json_object"}
        )
    except Exception:
        # Some routed models reject response_format; retry without it.
        try:
            response = client.chat.send(**request)
        except Exception as retry_exc:
            raise RuntimeError(
                f"OpenRouter JSON request failed for model '{model}': {retry_exc}"
            ) from retry_exc

    if not getattr(response, "choices", None):
        raise RuntimeError(f"OpenRouter returned no choices for model '{model}'.")

    text = getattr(response.choices[0].message, "content", None) or ""
    if not text.strip():
        raise RuntimeError(
            f"OpenRouter returned an empty JSON response for model '{model}'."
        )
    return text